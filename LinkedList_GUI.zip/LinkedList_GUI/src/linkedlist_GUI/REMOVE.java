package linkedlist_GUI;


import java.text.NumberFormat;
import javax.swing.JOptionPane;
import static linkedlist_GUI.HOME.DataStorage;
import static linkedlist_GUI.SEARCH.searchData;

public class REMOVE extends javax.swing.JFrame {

    modelhapus remove;
    
    public REMOVE() {
        initComponents();
        FillKategori();
        Text3.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    
    private void FillKategori(){
        modelhapus Hapus1 = new modelhapus("Selesai Antri", "none");
        modelhapus Hapus2 = new modelhapus("Hapus Belakang", "none");
        modelhapus Hapus3 = new modelhapus("Sesuai konten", "Masukkan Nama");

        Kategori.addItem(Hapus1);
        Kategori.addItem(Hapus2);
        Kategori.addItem(Hapus3);
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        LblRemove = new javax.swing.JLabel();
        Text3 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        Kategori = new javax.swing.JComboBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(290, 250));
        setResizable(false);
        setSize(new java.awt.Dimension(0, 0));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Delete Antrian");
        jLabel1.setToolTipText("");

        jLabel2.setText("Kategori");

        jButton1.setText("Remove");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        Kategori.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        Kategori.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KategoriActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(54, 54, 54)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(Text3, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(LblRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(0, 21, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton1)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Kategori, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Kategori, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(LblRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Text3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void KategoriActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KategoriActionPerformed
        remove = (modelhapus)Kategori.getSelectedItem();
        LblRemove.setText(remove.getHapusBelakang());
        if (Kategori.getSelectedItem().toString().equals("Selesai Antri")){
            Text3.setEnabled(false);
        }
        else if (Kategori.getSelectedItem().toString().equals("Hapus Belakang")){
            Text3.setEnabled(false);
        }
        else if (Kategori.getSelectedItem().toString().equals("Sesuai konten")){
            Text3.setEnabled(true);
        }
        else{
            Text3.setEnabled(false);
        }
    }//GEN-LAST:event_KategoriActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        if (Kategori.getSelectedItem().equals("")){
            JOptionPane.showMessageDialog(null, "Silahkan pilih Terlebbih Dahulu !");
        }
        else if (Kategori.getSelectedItem().toString().equals("Selesai Antri")){
            DataStorage.removeFirst();
            if (DataStorage.toString().equals("[]")){
                HOME.Panggil1.setText("");
                HOME.Antrian1.setText("");
                this.dispose();
            }
            else{
                HOME.Antrian1.setText(DataStorage.toString());
                HOME.Panggil1.setText(DataStorage.getFirst());
                this.dispose();
            }
        }
        else if(Kategori.getSelectedItem().toString().equals("Hapus Belakang")){
            DataStorage.removeLast();
            if (DataStorage.toString().equals("[]")){
                HOME.Panggil1.setText("");
                HOME.Antrian1.setText("");
            }
            else{
                HOME.Antrian1.setText(DataStorage.toString());
                HOME.Panggil1.setText(DataStorage.getFirst());
            }
            this.dispose();
        }
        else if (Kategori.getSelectedItem().toString().equals("Sesuai konten")){
            String data = Text3.getText();
            if(Text3.getText().equals("")){
              JOptionPane.showMessageDialog(null, "Silahkan Isi Nama Terlebbih Dahulu !");  
            }
            else if(searchData(data)) {
            DataStorage.remove(data);
            if (DataStorage.toString().equals("[]")){
                HOME.Panggil1.setText("");
                HOME.Antrian1.setText("");
            }
            else{
                HOME.Antrian1.setText(DataStorage.toString());
                HOME.Panggil1.setText(DataStorage.getFirst());
            }
            this.dispose();
            
            }
            else {
                JOptionPane.showMessageDialog(null, "Anda memasukkan nama yang tidak tersimpan di dalam list");   
            }   
        }
        else {
            JOptionPane.showMessageDialog(null, "Silahkan memilih kategori");
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(REMOVE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(REMOVE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(REMOVE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(REMOVE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new REMOVE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox Kategori;
    private javax.swing.JLabel LblRemove;
    private javax.swing.JTextField Text3;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
