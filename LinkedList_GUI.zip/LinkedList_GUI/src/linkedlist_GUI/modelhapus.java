package linkedlist_GUI;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TIUNIDA29
 */
public class modelhapus {
    private String SelesaiAntri;
    private String HapusBelakang;

    public modelhapus(String SelesaiAntri, String HapusBelakang) {
        this.SelesaiAntri = SelesaiAntri;
        this.HapusBelakang = HapusBelakang;
    }

    @Override
    public String toString() {
        return this.SelesaiAntri;
    }

    public void setSelesaiAntri(String SelesaiAntri) {
        this.SelesaiAntri = SelesaiAntri;
    }
    public String getSelesaiAntri() {
        return SelesaiAntri;
    }

    public void setHapusBelakang(String HapusBelakang) {
        this.HapusBelakang = HapusBelakang;
    }
    public String getHapusBelakang() {
        return HapusBelakang;
    }
    
}
