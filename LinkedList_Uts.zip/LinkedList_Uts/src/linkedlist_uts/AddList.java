/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlist_uts;

import java.util.InputMismatchException;
import static linkedlist_uts.LinkedList_Uts.Antrian;
import static linkedlist_uts.LinkedList_Uts.Menu;
import static linkedlist_uts.LinkedList_Uts.Input;
import static linkedlist_uts.LinkedList_Uts.DataStorage;
import static linkedlist_uts.LinkedList_Uts.ProgramExit;

/**
 *
 * @author TIUNIDA29
 */
public class AddList {
    
    public static void AddSwitcher() {
        
        boolean status = true;
        int indexMenu = 0;
        while(status) {
            try {
                status = false;
                System.out.print("Pilih Menu [1~3]: ");
                indexMenu = Input().nextInt();
            }
            catch(InputMismatchException e) {
                System.out.println("Masukan harus berupa Angka!");
                status = true;
            }
        }
        switch(indexMenu) {
            case 1: AddDataToLast(); break;
            case 2: AddDataToFirst(); break;
            case 3: AddDataLocation(); break;
        }
        Menu();
    }
        
    public static void AddMenu(){
        System.out.println("Pilih menu tambahan : "
                + "\n 1. biasa"
                + "\n 2. VVIP"
                + "\n 3. Khusus");
        AddSwitcher();
    }
    //Add_data {tidak dipakai dalam aplikasi}
//    public static void addData() {
//    System.out.print("Masukkan Nama: ");
//    String tempData = Ulang().nextLine();
//    dataStorage.add(tempData);
//    Antrian();
//    }
    
//Add_data location
    public static void AddDataLocation() {
        boolean status = true;
        int indexData = 0;
        Antrian();
        while(status) {
            System.out.print("Pilih Antrian yang ingin disisipi: [0-" + (DataStorage.size() - 1) + "]: ");
            try {
                status = false;
                indexData = Input().nextInt();
            }
            catch(InputMismatchException e) {
                    System.out.println("Antrian harus berupa Angka!");
                    status = true;
            }
        }
        System.out.print("Antrian yang ingin disisipkan ke- " + indexData + ": ");
        String tempData = Input().nextLine();
        DataStorage.add(indexData, tempData);
        Antrian();
    }
//Add_data HEAD or TAIL
    public static void AddDataToFirst() {
        System.out.print("Masukkan Nama : ");
        String tempData = Input().nextLine();
        DataStorage.addFirst(tempData);
        Antrian();
    }
//Add_data HEAD or TAIL
    public static void AddDataToLast() {
        System.out.print("Masukkan Nama : ");
        String tempData = Input().nextLine();
        DataStorage.addLast(tempData);
        Antrian();
    }
}
