/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlist_uts;

import java.util.InputMismatchException;
import static linkedlist_uts.AddList.AddSwitcher;
import static linkedlist_uts.LinkedList_Uts.Antrian;
import static linkedlist_uts.LinkedList_Uts.Input;
import static linkedlist_uts.LinkedList_Uts.DataStorage;
import static linkedlist_uts.LinkedList_Uts.Menu;
import static linkedlist_uts.Search.searchData;

/**
 *
 * @author TIUNIDA29
 */
public class RemoveList {
    
    public static void RemoveSwitcher() {
        
        boolean status = true;
        int indexMenu = 0;
        while(status) {
            try {
                status = false;
                System.out.print("Pilih Menu [1~3]: ");
                indexMenu = Input().nextInt();
            }
            catch(InputMismatchException e) {
                System.out.println("Masukan harus berupa Angka!");
                status = true;
            }
        }
        switch(indexMenu) {
            case 1: RemoveDataAtFirst(); break;
            case 2: RemoveDataAtLast(); break;
            case 3: RemoveData(); break;    
            case 4: RemoveDataByContent(); break;
        }
        Menu();
    }
    public static void RemoveMenu(){
    System.out.println("Pilih menu Remove : "
                + "\n 1. Depan"
                + "\n 2. Belakang"
                + "\n 3. N-Index"
                + "\n 4. Content");
        RemoveSwitcher();
    }
    //REMOVE
    public static void RemoveData() {
        boolean status = true;
        int indexData = 0;
        Antrian();
        while(status) {
            System.out.print("Pilih Antrian yang ingin dihapus: [0-" + (DataStorage.size() - 1) + "]: ");
            try {
                status = false;
                indexData = Input().nextInt();
            }
            catch(InputMismatchException e) {
                System.out.println("Antrian harus berupa Angka!");
                status = true;
            }
        }
        DataStorage.remove(indexData);
        Antrian();
    }
//REMOVE first
    public static void RemoveDataAtFirst() {
        DataStorage.removeFirst();
        Antrian();
    }
//REMOVE last
    public static void RemoveDataAtLast() {
        DataStorage.removeLast();
        Antrian();
    }
//REMOVE By Content 
    public static void RemoveDataByContent() {
        Antrian();
        System.out.print("Masukkan Nama yang ingin dihapus: ");
        String data = Input().nextLine();
        if(searchData(data)) {
            DataStorage.remove(data);
        }
        else {
            System.out.println("Anda memasukkan nama yang tidak tersimpan di dalam list");
        }
        Antrian();
    }
}
