/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlist_uts;


public class HOME {
    public static void main (String[]args){
        LinkedList_Uts X = new LinkedList_Uts();
        X.ProgramTitle();
        X.Antrian();
        X.Menu();
    }
}
