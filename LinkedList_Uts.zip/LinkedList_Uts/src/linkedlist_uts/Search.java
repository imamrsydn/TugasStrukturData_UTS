
package linkedlist_uts;

import static linkedlist_uts.LinkedList_Uts.Antrian;
import static linkedlist_uts.LinkedList_Uts.Input;
import static linkedlist_uts.LinkedList_Uts.DataStorage;


public class Search {
    //SEARCH
    public static boolean searchData(String data) {
        return DataStorage.contains(data);
    }
//SEARCH1
    public static void Search(){
        Antrian();
        System.out.print("Masukkan Nama yang ingin dicari: ");
        String data = Input().nextLine();
        if(searchData(data)) {
            System.out.println("\n\nHasil Pencarian = "+data);
        }
        else {
            System.out.println("Anda memasukkan nama yang tidak tersimpan di dalam list");
        }
        Antrian();
        
        
    }

}
