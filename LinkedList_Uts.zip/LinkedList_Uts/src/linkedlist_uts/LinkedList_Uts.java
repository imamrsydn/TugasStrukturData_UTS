
package linkedlist_uts;

/**
 *
 * @Imam Rasyidin Muqsith Rizqi Prasetyo
 * 402019611011
 */
import java.util.Scanner;
import java.util.LinkedList;
import java.util.InputMismatchException;

public class LinkedList_Uts {


//Lingked list
    public static LinkedList<String> DataStorage = new LinkedList<String>();
    
//Input
    public static Scanner Input() {
    return new Scanner(System.in);
    }
//agar menampilkan data setelah aksi
    public static void Antrian(){
    System.out.println("\nUrutan Antrian    : " + DataStorage);
    System.out.println("Total Antrian     : " + DataStorage.size());
    }
//EXIT
    public static void ProgramExit() {
        System.exit(0);
    }

    public static void ProgramTitle() {
        System.out.println("Program Untuk Antrian Bank");
    }

    public static void Switcher() {
        AddList AL = new AddList();
        RemoveList RL = new RemoveList();
        Search S = new Search();
        
        boolean status = true;
        int indexMenu = 0;
        while(status) {
            try {
                status = false;
                System.out.print("Pilih Menu [1~4]: ");
                indexMenu = Input().nextInt();
            }
            catch(InputMismatchException e) {
                System.out.println("Masukan harus berupa Angka!");
                status = true;
            }
        }

        switch(indexMenu) {
            case 1: AL.AddMenu();break;
            case 2: S.Search();break;
            case 3: RL.RemoveMenu(); break;
            case 4: ProgramExit(); break;
        }
        Menu();
    }

    public static void Menu() {

        System.out.println("\n<<<<<<==Menu Antrian==>>>>>>"
                         + "\n 1. Tambah Antrian"
                         + "\n 2. Search Data"
                         + "\n 3. Hapus Antrian"
                         + "\n 4. Program Exit");
        Switcher();
    }

}
